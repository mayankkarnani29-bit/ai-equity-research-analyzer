# Tata Steel Equity Analyzer (AI Equity Research & Financial Statement Analyzer)

Interactive case study: ratio analysis, CAPM/WACC, 5-year DCF and WACC / terminal-growth sensitivity for **Tata Steel Ltd (consolidated, FY2026)**, with a 10-step "How I Verify AI-Generated Output" section.

**Live demo:** <add your Vercel URL>
Educational use only. Not investment advice. No buy/sell call is made.

## Data
Inputs come from Tata Steel's Q4 FY2026 press release (15 May 2026) and S&P Global data via StockAnalysis.com, converted to INR crore. Price is the NSE close on 29 Sep 2026. Beta, market risk premium, growth rates and tax rate are analyst assumptions, not sourced. The page has a full source and reconciliation table. **Verify every input against the annual report before relying on it.**

## Model
FCF = operating cash flow - capex, grown at the stage-1 rate for 5 years; Gordon-growth terminal value; discounted at WACC. Equity value = EV - debt + cash. Simplified: book debt including leases, no minority adjustment, no peer comps.

## Tech / run
HTML, CSS and vanilla JavaScript, no build step. Open `index.html`, or deploy to Vercel with framework preset "Other". A hypothetical sample company can be loaded with the "Load Sample Company" button.
